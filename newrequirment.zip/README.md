# MathOperation
Math Operation for interview 
