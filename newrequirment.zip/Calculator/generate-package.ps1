$output='d:\\temp\\exam\\cimpl-seniordev-test.zip'
git archive --format zip --output $output master
echo "File generated to $output"
